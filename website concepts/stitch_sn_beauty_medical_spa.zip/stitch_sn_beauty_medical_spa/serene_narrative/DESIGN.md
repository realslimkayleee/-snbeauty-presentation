---
name: Serene Narrative
colors:
  surface: '#fdf8f7'
  surface-dim: '#ddd9d8'
  surface-bright: '#fdf8f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3f1'
  surface-container: '#f1edec'
  surface-container-high: '#ebe7e6'
  surface-container-highest: '#e6e2e0'
  on-surface: '#1c1b1b'
  on-surface-variant: '#494740'
  inverse-surface: '#313030'
  inverse-on-surface: '#f4f0ee'
  outline: '#7a776f'
  outline-variant: '#cbc6bd'
  surface-tint: '#605e5a'
  primary: '#605e5a'
  on-primary: '#ffffff'
  primary-container: '#f4efe9'
  on-primary-container: '#6f6c68'
  inverse-primary: '#cac6c0'
  secondary: '#675d4f'
  on-secondary: '#ffffff'
  secondary-container: '#efe0cf'
  on-secondary-container: '#6d6355'
  tertiary: '#79564e'
  on-tertiary: '#ffffff'
  tertiary-container: '#ffece8'
  on-tertiary-container: '#89645b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e6e2dc'
  primary-fixed-dim: '#cac6c0'
  on-primary-fixed: '#1d1b18'
  on-primary-fixed-variant: '#494642'
  secondary-fixed: '#efe0cf'
  secondary-fixed-dim: '#d2c4b4'
  on-secondary-fixed: '#211b10'
  on-secondary-fixed-variant: '#4e4539'
  tertiary-fixed: '#ffdad2'
  tertiary-fixed-dim: '#eabcb2'
  on-tertiary-fixed: '#2e150f'
  on-tertiary-fixed-variant: '#5f3f37'
  background: '#fdf8f7'
  on-background: '#1c1b1b'
  surface-variant: '#e6e2e0'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '400'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '400'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '400'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '400'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '400'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '300'
    lineHeight: '1.8'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '300'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 32px
  margin-desktop: 80px
  margin-tablet: 40px
  margin-mobile: 24px
  section-padding: 120px
---

## Brand & Style

This design system embodies "Quiet Luxury"—a philosophy that prioritizes the internal experience over external flash. It is designed for a discerning audience of 30-55 year olds who view beauty as a personal ritual of self-care rather than a clinical transaction. The aesthetic is anchored in **Minimalism** with a high-fashion **Editorial** influence, utilizing expansive whitespace to create a sense of breathing room and calm.

The visual narrative relies on "The Pause": deliberate gaps between elements that signal exclusivity and high-end curation. Imagery should be soft-focus, high-resolution, and deeply sensory, focusing on textures, skin health, and the serenity of the spa environment. The interface acts as a silent concierge—present and refined, but never demanding attention.

## Colors

The palette is a sophisticated study in warm neutrals, designed to mimic the tactile materials of a luxury sanctuary. 

- **Primary Background (#F4EFE9):** A warm cream that serves as the canvas, providing a softer, more premium feel than pure white.
- **Secondary Neutral (#E7D9C8):** Soft champagne used for subtle section differentiation and surface layering.
- **Muted Clay-Rose (#C99E94):** A sophisticated mid-tone used for secondary accents, icons, or soft UI highlights.
- **Bronze Accent (#9A7B58):** The metal-inspired tone used for calls to action, borders, and interactive states to provide weight and warmth.
- **Ink (#211C18):** A near-black with a warm undertone, ensuring high legibility while remaining softer than absolute black.

## Typography

The typographic strategy hinges on the contrast between the historic elegance of **Playfair Display** and the modern utility of **Inter**. 

Headlines should be treated with editorial care—generous leading and occasional italicization for emphasis. The body text uses a light weight (300) of Inter with increased line height (1.8) to maintain the "airy" feel of the brand. Labels and small navigation elements use uppercase tracking to create a sense of organized precision.

## Layout & Spacing

This design system uses a **Fixed Grid** model for desktop, centered within the viewport to create wide, protective margins. 

- **Density:** Low. Proximity is used to show relationship, but never at the expense of whitespace.
- **Sectioning:** Large vertical gaps (120px+) separate major content blocks to ensure the user processes one "ritual" or service at a time.
- **Responsive Behavior:** On mobile, margins reduce to 24px, and 3-column service grids collapse into a single-column stacked format, maintaining the oversized nature of the photography.

## Elevation & Depth

To maintain the "Quiet Luxury" aesthetic, physical shadows are largely avoided. Depth is conveyed through **Tonal Layers** and **Subtle Outlines**.

- **Surface Tiering:** Using the Champagne (#E7D9C8) background against the Cream (#F4EFE9) base to define content areas.
- **Ghost Borders:** Components like buttons and inputs utilize slim (1px) bronze outlines rather than heavy fills or dropshadows.
- **Image Overlays:** Occasionally, typography may slightly overlap image containers to create a sophisticated, layered editorial look without relying on 3D depth effects.

## Shapes

The shape language is controlled and intentional. Card containers and image frames utilize a 16px (`rounded-lg`) radius to soften the medical aspect of the spa, making it feel more like a wellness retreat. 

Buttons and pills use a more aggressive rounding to appear approachable and tactile, while interactive input fields maintain a standard 8px radius for professional clarity.

## Components

### Buttons
- **Primary:** Slim bronze (#9A7B58) 1px outline, pill-shaped. Text is `label-sm` (uppercase). Hover state introduces a very soft clay-rose (#C99E94) fill.
- **Secondary:** Text-only with a 1px bronze underline that expands on hover.

### Cards
- **Image-Led Cards:** Borderless. The image occupies the top 70% of the card with a 16px corner radius. Typography sits beneath with generous padding. No shadows; the depth comes from the image content itself.

### Navigation
- **Sticky Nav:** A minimal, semi-transparent bar using the Primary BG color with a backdrop-blur. Links are `label-sm` with wide letter spacing.

### Accordions (FAQ)
- **Slim Style:** No containing box. Divided by a single 1px horizontal line in #E7D9C8. The icon is a thin plus/minus or a chevron in bronze.

### Inputs
- **Forms:** Underlined style rather than fully boxed. The focus state changes the underline from champagne to bronze.